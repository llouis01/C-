// Loubens Louis, HW1, Q2
#include <iostream>
using namespace std;
int main() {

	// declare variables for radius, length and formulas.

	int user_nbr;
	double pi, sqr_area, circ_area, sphr_area;
	pi = 3.14;

	cout<<"Hi, enter an integer: "<<endl;
	
	// write in user data into declared variables
	cin >> user_nbr;
	sqr_area = user_nbr * user_nbr;
	circ_area = pi * user_nbr * user_nbr;
	
	/*4/3 will yield 1 because two integers divided will yield
	out an integer in return; so I fixed this by turning the 
	operands into decimal form manually.*/
	sphr_area =(4.00/3.00) * pi * user_nbr * user_nbr * user_nbr;
	
	// displays answers to user
	cout<<"\nThe area of a square with length "
		<<user_nbr<<" is "<<sqr_area<<". The area "
		<<"of a circle with radius "<<user_nbr
		<<" is "<<circ_area<<". Lastly, the area "
		<<"of a sphere with radius "<<user_nbr
		<<" is "<<sphr_area<<".";

return 0;
}
