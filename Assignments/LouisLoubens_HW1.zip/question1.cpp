// Loubens Louis, Homework 1, Q1
#include <iostream>
using namespace std;
int main() {

	// declare variables fr user input
	string usrnme;
	double hourly_rate;
	double weekly_hours;
	double weekly_check;

	cout<<" \nEnter your first name,"
   	    <<" hourly rate and"
   	    <<" how many hours you\n work a week"
   	    <<" in this specific order:" << endl;

	// write appropriate data into variables
	cin >> usrnme;
	cin >> hourly_rate;
	cin >> weekly_hours;
	weekly_check = hourly_rate * weekly_hours;

	// displays the user's info with wage calculation
	cout<<"\nHi "<<usrnme
	    <<". If you make $"
  	    <<hourly_rate<<"/hour "
	    <<"and work "<<weekly_hours
	    <<" hours/week, you make $"
	    <<weekly_check<<"/week.";
return 0;
}