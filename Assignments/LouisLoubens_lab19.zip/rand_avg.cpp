#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

// code to find average of elements randomly assigned to an array.

int main() {
	
	srand(time(0));
	int arr[10] = {0}; 
 	int sum, count, sum2, count2 = 0;

	for (int i = 0; i < 10; i++) {
		arr[i] = rand()%100 + 1;
			cout<<arr[i]<<", ";
	sum += arr[i];
	count++;
	}
	cout<<endl;

	double x = (double)sum/count;
	cout<<"\nInitial Average is "<<x;
	cout<<endl;

	for (int j = 0; j < 10; j++){
		if (x <= arr[j]) 
		sum2 += arr[j], count2++;
	}

	cout<<"\nFinal Average is "
	    <<(double)sum2/count2
	    <<endl;

return 0;
}