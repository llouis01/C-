// Loubens Louis, lab question 1
#include <iostream>
using namespace std;

int main() {

	int dim3 [2][3] = {{0,1,2},{3,4,5}};
	
	for (int r = 0; r < 2; r++){
		for (int c = 0; c < 3; c++){
			cout<<"\nElement at dim3[0][0]: "<<dim3[r][c]
			    <<endl;
	}
	}

return 0;
}