// Loubens Louis, Xtra cred.
#include <iostream>
using namespace std;

int main() {

	int dim3 [2][3] = {{0,1,2},{3,4,5}};
	int sum = 0, sum2 = 0, sum3 = 0;
	cout<<endl;
	
	for (int r = 0; r < 2; r++){
		for (int c = 0; c < 3; c++){
			cout<<dim3[r][c];
				sum += dim3[r][c];
	}
	}

	cout<<"\nSum of elements are "<<sum<<endl;

	for (int r2 = 0; r2 < 2; r2++){
		for (int c2 = 0; c2 < 1; c2++){
			sum2 += dim3[r2][c2];
	}
	}

	for (int r3 = 0; r3 < 2; r3++){
		for (int c3 = 0; c3 < 1; c3++){
			sum3 += dim3[r3][c3];
	}
	}

	cout<<"Sum of row 0: "<<sum2<<"."<<endl;
	cout<<"Sum of row 1: "<<sum3<<"."<<endl;

return 0;
}