// Loubens Louis, Lab 25, xtra cred.
#include <iostream>
using namespace std;

int main(int argc, char *argv[]){

string str1 = argv[1], str2 = argv[2];

cout<<"\nThe result is \""<<str1+str2
    <<"\"."<<endl;

return 0;
}