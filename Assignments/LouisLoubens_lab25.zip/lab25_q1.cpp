// Loubens Louis, Lab 25, Q1
#include <iostream>
using namespace std;

int main(int argc, char *argv[]){

	cout<<"\nThe first command line"
	    <<" argument is "<<argv[0]<<".";
	cout<<endl;

return 0;
}

