#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;

// EXTRA CREDIT

double arrayAvg(int Arr[], int size);
int largestNum(int Arr[], int size);

int main() {
  
  srand(time(0));
  int ur_size = 0;
  cout<<"Enter an array size below 100: ";
  cin>>ur_size;
  int Array[ur_size];
  // need to change the upper bound of the for loop to reach all the ur_size array positions
  if (ur_size >= 100) exit(0);
	else
  for (int i = 0; i < ur_size; i++){
	  // rather than mod by ur_size, pick something like 100, unless you have the user specify a range
		// 100 did not work; caused program to end without any calculations.
    Array[i] = rand()%ur_size+1;
  }

  cout<<"\nThe elements assigned to array are: ";
 	 for (int a = 0; a < ur_size; a++){
    		cout<<Array[a];
  }
  cout<<endl;

  cout<<"\nThe average of the elements"
      <<" in the array is "<<arrayAvg(Array, ur_size)
      <<"."<<endl;

  cout<<"\nThe largest element in the array"
      <<" is "<<largestNum(Array, ur_size)<<"."
      <<endl;

return 0;
}


  double arrayAvg(int Array[], int ur_size){
	int sum = 0;	  
        for (int a = 0; a < ur_size; a++){
        sum += Array[a];
	}
	return (double)sum/ur_size; // the return statement will do what the cout would have done.
}
	
  int largestNum(int Array[], int ur_size){
	 int max = Array[0]; // first elm set to max then loop to compare each following to the current elm
    	 for (int a = 0; a < ur_size; a++){
		if(Array[a]>max) max = Array[a]; // continually place highest elm in max and compre to next elm
    }
	return max;
  }