#include <iostream>
using namespace std;


string data[5] = {"Kelly", "Jack", "Freddy", "Arthur", "Freddy"};

int main() {

	int numberFreddy(string arr[], int size);
	cout << numberFreddy(data, 5) << endl; // prints 2

return 0;
}

	int count = 0;
	int numberFreddy(string arr[], int size){
	for (int i = 0; i < size; i++){
		if (data[i] == "Freddy") count += 1;
}
	return count;
}
