//Loubens Louis, Xtra Cred., Q2
#include <iostream>
using namespace std;

int main() {
	
	double SquareNum(double a); // prototype func in main()

	double x = 0;
	cout<<"\nEnter a number: \n";
	cin>>x;
	cout<<endl;

	cout<<"The square root of "<<x
	    <<" is "<<SquareNum(x)<<"." // call func in main()
	    <<endl;

return 0;
}

double SquareNum(double a) { // define func outside of main()
	return a*a;
}
	